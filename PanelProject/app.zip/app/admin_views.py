from . import *

@app.route('/')
def login():
    return render_template('login.html')

@app.route('/dashboard',methods = ['POST', 'GET'])
def dashboard():
    return render_template('dashboard.html')